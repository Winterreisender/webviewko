java -XstartOnFirstThread -cp ./target/webviewjar-1.0-SNAPSHOT.jar SimpleTest

